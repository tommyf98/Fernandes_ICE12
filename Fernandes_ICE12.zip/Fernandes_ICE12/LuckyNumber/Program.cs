﻿using System;
/** 
 * Name: Tao Ji Yang
 * Courses: NMAD.180:PROGRAMMING FUNDAMENTALS I:MOBILE DOMAIN
 * Due Date; 2/26/2021
 * Purpose: ICE 12 Making Array with Lucky number from 1 - 10
 * Caveats: No problem at all however I just did not know how to use Array inside the if statement. 
 */
namespace Fernandes_ICE12
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] LuckyNumber = new int[10];

            // 1 to 10 number//
            LuckyNumber[1] = 8;
            LuckyNumber[2] = 24;
            LuckyNumber[3] = 7;
            LuckyNumber[4] = 23;
            LuckyNumber[5] = 6;
            LuckyNumber[6] = 10;
            LuckyNumber[7] = 4;
            LuckyNumber[8] = 12;
            LuckyNumber[9] = 88;
            //Random maker//
            //Source Helper: https://stackoverflow.com/questions/8870193/making-an-array-of-random-ints//
            Random RandomLUCKYNumber = new Random();
            int number = RandomLUCKYNumber.Next(LuckyNumber.Length) + 1;


            //Output Final Lucky Number//
            Console.WriteLine("The lucky number is {0}!", LuckyNumber[number]);



        }
    }
}
