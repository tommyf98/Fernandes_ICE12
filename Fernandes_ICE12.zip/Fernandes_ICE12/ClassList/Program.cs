﻿using System;
/** 
 * Name: Tao Ji Yang
 * Courses: NMAD.180:PROGRAMMING FUNDAMENTALS I:MOBILE DOMAIN
 * Due Date; 2/26/2021
 * Purpose: ICE 12 Classlist include the classmate. 
 * Caveats: No problem at all. 
 */
namespace ClassList
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] classList = new string[5];



            classList[0] = "Menna";
            classList[1] = "Tao Ji";
            classList[2] = "David";
            classList[3] = "Sahand";
            classList[4] = "Alvin";

            Console.WriteLine("Who is in your PF1 class?");

            Console.WriteLine(classList[0]);
            Console.WriteLine(classList[1]);
            Console.WriteLine(classList[2]);
            Console.WriteLine(classList[3]);
            Console.WriteLine(classList[4]);





        }
    }
}
